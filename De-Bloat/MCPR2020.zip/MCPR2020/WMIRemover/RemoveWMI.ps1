﻿
$AVs =  gwmi -namespace root\SecurityCenter2 -ClassName AntiVirusProduct

foreach ($AVInstance in $AVs)
{
	#$AVInstance.instanceGuid
	
	if ($AVInstance.instanceGuid -eq "{F682A51C-4EAD-6A3A-F460-B9C1D4A2DB09}")
	{		
        $AVInstance.Delete()
	}
	
	if ($AVInstance.instanceGuid -eq "{8BCDACFA-D264-3528-5EF8-E94FD0BC1FBC}")
	{	
		$AVInstance.Delete()
	}	
	
}


$ASWs =  gwmi -namespace root\SecurityCenter2 -ClassName AntiSpywareProduct

foreach ($ASWInstance in $ASWs)
{
	#$ASWInstance.instanceGuid
	
	#if ($ASWInstance.instanceGuid -eq "{B3F62DDF-980B-3470-75A7-407A2E6F58C7}")
	#{
	
        
	#}
	
	#if ($ASWInstance.instanceGuid -eq "{CEB92439-04C2-6B62-DF3F-10F42A719C72}")
	#{
	
		
	#}	
	
}



$FWs =  gwmi -namespace root\SecurityCenter2 -ClassName FirewallProduct

foreach ($FWInstance in $FWs)
{
	#$FWInstance.instanceGuid
	
	if ($FWInstance.instanceGuid -eq "{B3F62DDF-980B-3470-75A7-407A2E6F58C7}")
	{	
        $FWInstance.Delete()
        
	}
	
	if ($FWInstance.instanceGuid -eq "{CEB92439-04C2-6B62-DF3F-10F42A719C72}")
	{	
        $FWInstance.Delete()
		
	}		
}